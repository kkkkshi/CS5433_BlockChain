from hashlib import sha256
import secrets

netid = "af535" # change to your netid

# Put your solution generation code here

